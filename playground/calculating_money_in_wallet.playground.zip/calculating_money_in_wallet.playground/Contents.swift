
//will return total and count
//InWallet is name of param in function
func calculateWallet(InWallet array: [Int], type: Int? = nil) -> (total: Int, count: Int){
    var sum = 0
    var count = 0
    
    for value in wallet {
        if (type == nil) || (value == type!) {
            sum += value
            count+=1
        }
    }
    return (sum, count)
}

//will calculate and return total money in sequance
func calculateWalletRange(inSequnce range: Int...) -> Int {
    var sum = 0
    
    for value in range {
        sum += value
    }
    return sum
}

let wallet = [10, 15, 25, 220, 330, 100]
var (money, count) = calculateWallet(InWallet: wallet, type: nil)
var total = calculateWalletRange(inSequnce: 10, 15, 22, 30, 150, 170, 220)

print("Total money in sequence: \(total)")
print("Total money: \(money) and Count: \(count)")

